const { Create,Read,GetRandNumber,ConcatFiles } = require('./functions');

function Main() {
  Create(1, "Hello");
  Read(1);
  console.log("Number of function 3: " + GetRandNumber());
  ConcatFiles(GetRandNumber());
  
}



Main();