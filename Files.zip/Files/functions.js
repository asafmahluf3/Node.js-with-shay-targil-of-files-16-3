const fs = require('node:fs/promises');
const path = require('node:path');

exports.Create = async (n, str) => {
    try {
        await fs.writeFile(path.join(__dirname, `file${n}.txt`), str);
        console.log('Function 1 Done.');
    } catch (err) {
        console.error(err);
    }
}


exports.Read = async (n) => {
    try {
        //קריאת התוכן מתוך הקובץ
        let data = await fs.readFile(path.join(__dirname, `file${n}.txt`));
        console.log('Function 2 Done.' + " " + data.toString());
    } catch (err) {
        console.error(err);
    }
}


exports.GetRandNumber = () => {
    
    let number = Math.floor(Math.random() * 6);
    return number;

}



exports.ConcatFiles = async (n) => {
    try {
                // מחיקת הקובץ
        await fs.unlink(path.join(__dirname, 'concatTextFile.txt'));

        console.log("The random number in last function:" + n);

        for (let index = 1; index < 6; index++) {
            if(index === n) break;
            //קריאת התוכן מתוך הקובץ
            let data = await fs.readFile(path.join(__dirname, `file${index}.txt`));
             // //הוספת טקסט לקובץ 
            await fs.appendFile(path.join(__dirname, 'stringtxt.txt'), `\n${data}`);

            
        }



                //שינוי שם הקובץ
        await fs.rename(path.join(__dirname, 'stringtxt.txt'), path.join(__dirname, 'concatTextFile.txt'));


        console.log(n);
    } catch (err) {
        console.error(err);
    }
}

        // //קריאת התוכן מתוך הקובץ
        // let data = await fs.readFile(path.join(__dirname, 'files', 'first.txt'));
        // //מחיקת הקובץ
        // await fs.unlink(path.join(__dirname, 'files', 'first.txt'));
        // //יצירת קובץ חדש עם טקסט

                // //הוספת טקסט לקובץ 
        // await fs.appendFile(path.join(__dirname, 'files', 'new.txt'), '\nOreo is YUM, Oreo is GOOD!!');
        // //שינוי שם הקובץ
        // await fs.rename(path.join(__dirname, 'files', 'new.txt'), path.join(__dirname, 'files', 'oreoPromo.txt'));
